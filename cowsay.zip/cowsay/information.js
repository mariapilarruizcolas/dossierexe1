const user = {
    name: 'maz',
    campus: 'wildparis'

}

module.exports = user