const user = require('./information');
const cowsay = require("cowsay");

console.log(user);
console.log(cowsay.say({text:`my name is ${user.name}, from ${user.campus}`}));