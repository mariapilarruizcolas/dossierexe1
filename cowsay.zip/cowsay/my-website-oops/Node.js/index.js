const chalk = require("chalk");

console.log(chalk.green('jenny'));

console.log(chalk.blackBright('abdou'));

